CKEDITOR.plugins.setLang("autoembed","pl",{embeddingInProgress:"Osadzanie wklejonego adresu URL...",embeddingFailed:"Ten adres URL multimediów nie może być automatycznie osadzony."});
