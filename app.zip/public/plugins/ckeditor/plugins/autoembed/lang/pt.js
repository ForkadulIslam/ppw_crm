CKEDITOR.plugins.setLang("autoembed","pt",{embeddingInProgress:"Trying to embed pasted URL...",embeddingFailed:"Não foi possível embeber diretamente este URL."});
