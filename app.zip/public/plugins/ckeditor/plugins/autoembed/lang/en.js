CKEDITOR.plugins.setLang("autoembed","en",{embeddingInProgress:"Trying to embed pasted URL...",embeddingFailed:"This URL could not be automatically embedded."});
