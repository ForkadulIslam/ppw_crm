CKEDITOR.plugins.setLang("autoembed","eu",{embeddingInProgress:"Itsatsitako URLa txertatzen saiatzen...",embeddingFailed:"URL hau ezin izan da automatikoki txertatu."});
