CKEDITOR.plugins.setLang("autoembed","it",{embeddingInProgress:"Prova a incorporare l'URL incollato...",embeddingFailed:"Non è stato possibile incorporare automaticamente questo URL."});
