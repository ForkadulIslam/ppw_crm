CKEDITOR.plugins.setLang("autoembed","ru",{embeddingInProgress:"Пытаемся встроить вставленный URL...",embeddingFailed:"Данный URL не может быть встроен автоматически."});
