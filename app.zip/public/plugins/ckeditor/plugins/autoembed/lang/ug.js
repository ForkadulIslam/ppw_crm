CKEDITOR.plugins.setLang("autoembed","ug",{embeddingInProgress:"سىڭدۈرۈلگەن چاپلانغان URL نى سىناۋاتىدۇ…",embeddingFailed:"بۇ URL نى ئۆزلۈكىدىن سىڭدۈرەلمەيدۇ."});
