CKEDITOR.plugins.setLang("bidi","sq",{ltr:"Drejtimi i tekstit nga e majta në të djathtë",rtl:"Drejtimi i tekstit nga e djathta në të majtë"});
