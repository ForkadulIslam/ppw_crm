CKEDITOR.plugins.setLang("bidi","af",{ltr:"Skryfrigting van links na regs",rtl:"Skryfrigting van regs na links"});
