CKEDITOR.plugins.setLang("bidi","fo",{ltr:"Tekstkós frá vinstru til høgru",rtl:"Tekstkós frá høgru til vinstru"});
