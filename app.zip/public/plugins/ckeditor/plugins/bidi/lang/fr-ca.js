CKEDITOR.plugins.setLang("bidi","fr-ca",{ltr:"Direction du texte de gauche à droite",rtl:"Direction du texte de droite à gauche"});
