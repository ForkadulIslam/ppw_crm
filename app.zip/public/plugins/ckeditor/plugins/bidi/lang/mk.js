CKEDITOR.plugins.setLang("bidi","mk",{ltr:"Насока на текст: од лево кон десно",rtl:"Насока на текст: од десно кон лево"});
