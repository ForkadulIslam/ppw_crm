CKEDITOR.plugins.setLang("bidi","hu",{ltr:"Szöveg iránya balról jobbra",rtl:"Szöveg iránya jobbról balra"});
