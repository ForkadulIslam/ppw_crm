CKEDITOR.plugins.setLang("bidi","ms",{ltr:"Text direction from left to right",rtl:"Text direction from right to left"});
