CKEDITOR.plugins.setLang("bidi","ja",{ltr:"テキストの向き : 左から右へ",rtl:"テキストの向き : 右から左へ"});
