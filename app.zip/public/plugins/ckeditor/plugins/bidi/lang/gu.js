CKEDITOR.plugins.setLang("bidi","gu",{ltr:"ટેક્ષ્ત્ ની દિશા ડાબે થી જમણે",rtl:"ટેક્ષ્ત્ ની દિશા જમણે થી ડાબે"});
