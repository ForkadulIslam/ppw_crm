CKEDITOR.plugins.setLang("bidi","bg",{ltr:"Посока на текста от ляво на дясно",rtl:"Посока на текста от дясно на ляво"});
