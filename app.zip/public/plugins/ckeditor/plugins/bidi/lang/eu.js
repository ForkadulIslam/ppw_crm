CKEDITOR.plugins.setLang("bidi","eu",{ltr:"Testuaren norantza ezkerretik eskuinera",rtl:"Testuaren norantza eskuinetik ezkerrera"});
