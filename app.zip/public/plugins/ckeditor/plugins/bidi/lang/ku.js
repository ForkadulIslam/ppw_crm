CKEDITOR.plugins.setLang("bidi","ku",{ltr:"ئاراستەی نووسە لە چەپ بۆ ڕاست",rtl:"ئاراستەی نووسە لە ڕاست بۆ چەپ"});
