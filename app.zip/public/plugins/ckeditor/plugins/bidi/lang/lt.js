CKEDITOR.plugins.setLang("bidi","lt",{ltr:"Tekstas iš kairės į dešinę",rtl:"Tekstas iš dešinės į kairę"});
