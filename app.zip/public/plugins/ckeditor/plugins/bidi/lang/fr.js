CKEDITOR.plugins.setLang("bidi","fr",{ltr:"Direction du texte de la gauche vers la droite",rtl:"Direction du texte de la droite vers la gauche"});
