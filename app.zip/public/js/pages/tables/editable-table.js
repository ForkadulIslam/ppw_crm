$(function () {
    $('#mainTable').editableTableWidget();
});
